import getFucked from "./lib/client";

setInterval(() => {
  new getFucked();
}, 10 * 1000);
