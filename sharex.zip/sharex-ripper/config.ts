export default {
  upload_url: "https://dash.lunardev.group/api/upload",
  auth_key: "duG8eZ9hXJroARYHmdmVN7j7.MTY2NjE2NDQ5NzM1MQ",
};
